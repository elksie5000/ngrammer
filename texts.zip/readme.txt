The files A1 to A6 contain samples from 3 short stories written by Author A.
The files B1 to B6 contain samples from 3 short stories written by Author B.
The file c1.txt is from a separate short story writtent by one of the authors. 
By automated means only, attempt to determine (along the lines indicated in 
the assignment text), which author was responsible for sample C1.txt.